[
  {
    "name": "a",
    "param": [
      "x",
      "y"
    ],
    "line": 2,
    "character": 12,
    "last": 4,
    "lastcharacter": 5
  },
  {
    "name": "b",
    "line": 7,
    "character": 12,
    "last": 12,
    "lastcharacter": 2
  },
  {
    "name": "c",
    "line": 8,
    "character": 16,
    "last": 10,
    "lastcharacter": 6
  },
  {
    "var": [
      "e"
    ],
    "name": "d",
    "line": 15,
    "character": 12,
    "last": 20,
    "lastcharacter": 2
  },
  {
    "name": "e",
    "param": [
      "x",
      "y"
    ],
    "line": 16,
    "character": 23,
    "last": 18,
    "lastcharacter": 6
  },
  {
    "name": "f",
    "line": 23,
    "character": 12,
    "last": 27,
    "lastcharacter": 2
  },
  {
    "name": "(empty)",
    "line": 24,
    "character": 16,
    "last": 26,
    "lastcharacter": 6
  },
  {
    "name": "g",
    "line": 30,
    "character": 12,
    "last": 30,
    "lastcharacter": 58
  },
  {
    "name": "h",
    "line": 30,
    "character": 39,
    "last": 30,
    "lastcharacter": 56
  },
  {
    "name": "j",
    "line": 34,
    "character": 19,
    "last": 34,
    "lastcharacter": 36
  },
  {
    "name": "k",
    "line": 35,
    "character": 20,
    "last": 35,
    "lastcharacter": 24
  },
  {
    "name": "23",
    "line": 36,
    "character": 18,
    "last": 36,
    "lastcharacter": 22
  },
  {
    "name": "computedStr",
    "line": 37,
    "character": 32,
    "last": 37,
    "lastcharacter": 36
  },
  {
    "name": "(expression)",
    "line": 38,
    "character": 33,
    "last": 38,
    "lastcharacter": 37
  },
  {
    "name": "get getter",
    "line": 39,
    "character": 16,
    "last": 39,
    "lastcharacter": 20
  },
  {
    "name": "set setter",
    "line": 40,
    "character": 16,
    "last": 40,
    "lastcharacter": 20
  },
  {
    "name": "(empty)",
    "line": 43,
    "character": 17,
    "last": 43,
    "lastcharacter": 21
  },
  {
    "name": "(empty)",
    "line": 48,
    "character": 27,
    "last": 48,
    "lastcharacter": 31
  },
  {
    "name": "(empty)",
    "line": 50,
    "character": 37,
    "last": 50,
    "lastcharacter": 41
  },
  {
    "name": "(empty)",
    "line": 52,
    "character": 13,
    "last": 52,
    "lastcharacter": 53
  },
  {
    "name": "l",
    "line": 52,
    "character": 34,
    "last": 52,
    "lastcharacter": 38
  },
  {
    "name": "(expression)",
    "line": 52,
    "character": 69,
    "last": 52,
    "lastcharacter": 73
  },
  {
    "name": "viaDot",
    "line": 54,
    "character": 21,
    "last": 54,
    "lastcharacter": 25
  },
  {
    "name": "viaBracket",
    "line": 56,
    "character": 28,
    "last": 56,
    "lastcharacter": 32
  },
  {
    "name": "(expression)",
    "line": 57,
    "character": 37,
    "last": 57,
    "lastcharacter": 41
  },
  {
    "name": "VarDeclClass",
    "line": 65,
    "character": 15,
    "last": 65,
    "lastcharacter": 19
  },
  {
    "name": "func",
    "line": 66,
    "character": 15,
    "last": 66,
    "lastcharacter": 19
  },
  {
    "name": "method",
    "line": 67,
    "character": 10,
    "last": 67,
    "lastcharacter": 14
  },
  {
    "name": "get getter",
    "line": 68,
    "character": 14,
    "last": 68,
    "lastcharacter": 18
  },
  {
    "name": "set setter",
    "line": 69,
    "character": 14,
    "last": 69,
    "lastcharacter": 18
  },
  {
    "name": "genMethod",
    "line": 70,
    "character": 14,
    "last": 70,
    "lastcharacter": 18
  },
  {
    "name": "staticGenMethod",
    "line": 71,
    "character": 27,
    "last": 71,
    "lastcharacter": 31
  },
  {
    "name": "(empty)",
    "line": 74,
    "character": 26,
    "last": 74,
    "lastcharacter": 30
  },
  {
    "name": "default",
    "line": 76,
    "character": 25,
    "last": 76,
    "lastcharacter": 29
  }
]
