//jshint -W008

var a = .12;
//jshint +W008
var b = .12;
