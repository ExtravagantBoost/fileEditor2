/*jslint eqeq: false */

var i, j;
if (i == j) {
}
