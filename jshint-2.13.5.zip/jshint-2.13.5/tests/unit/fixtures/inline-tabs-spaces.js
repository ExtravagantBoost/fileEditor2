function a() {
    //      jshint unused: true     
    var x;
}

function b() {
    /*      jshint  
    unused: true
    */
    var y;
}

function c() {
    /*      jshint      
        unused: true
    */
    var z;
}
