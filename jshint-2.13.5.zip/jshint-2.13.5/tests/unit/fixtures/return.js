function foo() {
    var x = 10;
    return x = 12;
}

function boo() {
    var a = 11;
    return function () {
        return (a);
    };
}

function jazz() {
    return true;
}

function jar() {
    return 1 > 2;
}

function wee() {
    return 2 - 1;
}

function zee() {
    return (1 < 2) ? "yes" : "no";
}

function zar() {
    return "blue";
}

function baz() {
    return 1;
}

function bar() {
    return
    {};
}
