if (cond)
    return true;

for (;;)
    doSomething();

while (true)
    doSomething();

do
    doSomething();
while (true);