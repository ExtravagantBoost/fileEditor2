export * from './foo.js';
export * foo;
export * from 78;
