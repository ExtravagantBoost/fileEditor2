var a = "test maxlen";
var b = "test maxlen ";
var c = "test maxlen  ";
  //  http://jshint.com/docs/
var someCode; // http://jshint.com/docs/
  // http://jshint.com/docs/ is a good website
  // http://jshint.com/docs/
  /* http://jshint.com/docs/
   */
a = 23;
  /*
   * http://jshint.com/docs/
   */
a = 23;
/*
   http://jshint.com/docs/
 */
/*jshint ignore:start*/
// third-party code
// this very very very very very very very very very very very very very long comment line will produce warning "Line is too long." unless W101 is explicitly disabled
/*jshint ignore:end*/
